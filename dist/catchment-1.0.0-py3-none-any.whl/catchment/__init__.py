"""Package containing the bulk of code for the rain and river data system."""
